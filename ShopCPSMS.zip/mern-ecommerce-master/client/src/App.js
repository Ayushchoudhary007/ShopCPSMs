import React from 'react';

const App = () => <div>Hello from ashraf kabir</div>;

export default App;
